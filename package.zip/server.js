require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Server } = require('socket.io');
const pool = require('./db');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(cors());
app.use(express.json());

const JWT_SECRET = process.env.JWT_SECRET;
const PORT = process.env.PORT || 3000;

function authenticate(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(401).json({ error: 'Нет токена' });
  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    res.status(401).json({ error: 'Неверный токен' });
  }
}

// Регистрация
app.post('/api/register', async (req, res) => {
  const { name, phone, email, password, address, role } = req.body;
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const result = await pool.query(
      'INSERT INTO users (name, phone, email, password, address, role) VALUES ($1,$2,$3,$4,$5,$6) RETURNING id, name, email, role',
      [name, phone, email, hashedPassword, address, role || 'client']
    );
    res.json(result.rows[0]);
  } catch (err) {
    console.error('Ошибка регистрации:', err.message);
    // 👇 Теперь клиент увидит настоящую ошибку, а не общее сообщение
    res.status(500).json({ error: err.message });
  }
});

// Логин
app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await pool.query('SELECT * FROM users WHERE email=$1', [email]);
    if (user.rows.length === 0) return res.status(400).json({ error: 'Пользователь не найден' });
    const valid = await bcrypt.compare(password, user.rows[0].password);
    if (!valid) return res.status(400).json({ error: 'Неверный пароль' });
    const token = jwt.sign(
      { id: user.rows[0].id, email: user.rows[0].email, role: user.rows[0].role },
      JWT_SECRET,
      { expiresIn: '365d' }
    );
    res.json({ token, user: { id: user.rows[0].id, name: user.rows[0].name, role: user.rows[0].role } });
  } catch (err) {
    res.status(500).json({ error: 'Ошибка входа' });
  }
});

// Создание заказа (клиент)
app.post('/api/order/create', authenticate, async (req, res) => {
  const { pickup_address, delivery_address, description, price } = req.body;
  if (req.user.role !== 'client') return res.status(403).json({ error: 'Только клиенты могут создавать заказы' });
  try {
    const result = await pool.query(
      'INSERT INTO orders (client_id, pickup_address, delivery_address, description, price, status) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *',
      [req.user.id, pickup_address, delivery_address, description, price, 'new']
    );
    const newOrder = result.rows[0];
    io.emit('new_order', newOrder);
    res.json(newOrder);
  } catch (err) {
    console.error('Ошибка создания заказа:', err);
    res.status(500).json({ error: 'Ошибка создания заказа' });
  }
});

// Получить все заказы (фильтр для курьера)
app.get('/api/orders', authenticate, async (req, res) => {
  try {
    let orders;
    if (req.user.role === 'admin') {
      orders = await pool.query('SELECT * FROM orders ORDER BY created_at DESC');
    } else if (req.user.role === 'client') {
      orders = await pool.query('SELECT * FROM orders WHERE client_id=$1 ORDER BY created_at DESC', [req.user.id]);
    } else if (req.user.role === 'courier') {
      orders = await pool.query(
        `SELECT * FROM orders
         WHERE (courier_id=$1 OR status='new')
           AND (status != 'delivered' OR created_at > NOW() - INTERVAL '30 minutes')
         ORDER BY created_at DESC`,
        [req.user.id]
      );
    }
    res.json(orders.rows);
  } catch (err) {
    console.error('Ошибка получения заказов:', err);
    res.status(500).json({ error: 'Ошибка получения заказов' });
  }
});

// Курьер принимает заказ
app.post('/api/order/accept', authenticate, async (req, res) => {
  if (req.user.role !== 'courier') return res.status(403).json({ error: 'Только курьеры' });
  const { order_id } = req.body;
  try {
    const order = await pool.query('UPDATE orders SET courier_id=$1, status=$2 WHERE id=$3 AND status=$4 RETURNING *',
      [req.user.id, 'accepted', order_id, 'new']);
    if (order.rows.length === 0) return res.status(400).json({ error: 'Заказ уже принят' });
    io.to(`user_${order.rows[0].client_id}`).emit('order_accepted', order.rows[0]);
    res.json(order.rows[0]);
  } catch (err) {
    console.error('Ошибка принятия заказа:', err);
    res.status(500).json({ error: 'Ошибка принятия заказа' });
  }
});

// Завершить заказ
app.post('/api/order/finish', authenticate, async (req, res) => {
  if (req.user.role !== 'courier') return res.status(403).json({ error: 'Только курьеры' });
  const { order_id } = req.body;
  try {
    const order = await pool.query(
      'UPDATE orders SET status=$1 WHERE id=$2 AND courier_id=$3 RETURNING *',
      ['delivered', order_id, req.user.id]
    );
    if (order.rows.length === 0) return res.status(400).json({ error: 'Заказ не найден или не принадлежит вам' });
    io.to(`user_${order.rows[0].client_id}`).emit('order_delivered', order.rows[0]);
    res.json(order.rows[0]);
  } catch (err) {
    console.error('Ошибка завершения заказа:', err);
    res.status(500).json({ error: 'Ошибка завершения заказа' });
  }
});

// Обновление геолокации курьера
app.post('/api/courier/location', authenticate, async (req, res) => {
  if (req.user.role !== 'courier') return res.status(403).json({ error: 'Только курьеры' });
  const { lat, lng } = req.body;
  try {
    await pool.query('UPDATE couriers SET lat=$1, lng=$2 WHERE user_id=$3', [lat, lng, req.user.id]);
    io.emit('courier_location', { courier_id: req.user.id, lat, lng });
    res.json({ success: true });
  } catch (err) {
    console.error('Ошибка обновления локации:', err);
    res.status(500).json({ error: 'Ошибка обновления' });
  }
});

// Статус курьера online/offline (автосоздание с координатами Санкт-Петербурга)
app.post('/api/courier/status', authenticate, async (req, res) => {
  if (req.user.role !== 'courier') return res.status(403).json({ error: 'Только курьеры' });
  const { is_online } = req.body;
  try {
    const existing = await pool.query('SELECT id FROM couriers WHERE user_id = $1', [req.user.id]);

    if (existing.rows.length === 0) {
      await pool.query(
        'INSERT INTO couriers (user_id, is_online, lat, lng) VALUES ($1, $2, 59.9343, 30.3351)',
        [req.user.id, is_online]
      );
    } else {
      await pool.query('UPDATE couriers SET is_online = $1 WHERE user_id = $2', [is_online, req.user.id]);
    }

    res.json({ is_online });
  } catch (err) {
    console.error('Ошибка статуса курьера:', err);
    res.status(500).json({ error: 'Ошибка статуса' });
  }
});

// Профиль текущего пользователя (для курьеров возвращает координаты и транспорт)
app.get('/api/profile', authenticate, async (req, res) => {
  try {
    let user;
    if (req.user.role === 'courier') {
      user = await pool.query(
        `SELECT u.id, u.name, u.phone, u.email, u.address, u.role,
                c.lat, c.lng, c.transport, c.is_online
         FROM users u
         LEFT JOIN couriers c ON c.user_id = u.id
         WHERE u.id = $1`,
        [req.user.id]
      );
    } else {
      user = await pool.query(
        'SELECT id, name, phone, email, address, role FROM users WHERE id=$1',
        [req.user.id]
      );
    }
    if (user.rows.length === 0) return res.status(404).json({ error: 'Пользователь не найден' });
    res.json(user.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Ошибка получения профиля' });
  }
});

// Обновление профиля (имя, адрес, транспорт)
app.put('/api/profile', authenticate, async (req, res) => {
  const { name, address, transport } = req.body;
  try {
    await pool.query(
      'UPDATE users SET name = COALESCE($1, name), address = COALESCE($2, address) WHERE id = $3',
      [name, address, req.user.id]
    );
    if (req.user.role === 'courier' && transport !== undefined) {
      await pool.query(
        'UPDATE couriers SET transport = $1 WHERE user_id = $2',
        [transport, req.user.id]
      );
    }
    res.json({ success: true });
  } catch (err) {
    console.error('Ошибка обновления профиля:', err);
    res.status(500).json({ error: 'Ошибка обновления профиля' });
  }
});

// Список онлайн-курьеров (с координатами)
app.get('/api/couriers/online', authenticate, async (req, res) => {
  try {
    const couriers = await pool.query(
      `SELECT u.id, u.name, c.lat, c.lng, c.transport
       FROM couriers c
       JOIN users u ON u.id = c.user_id
       WHERE c.is_online = true AND c.lat IS NOT NULL AND c.lng IS NOT NULL`
    );
    res.json(couriers.rows);
  } catch (err) {
    res.status(500).json({ error: 'Ошибка получения курьеров' });
  }
});

// Баланс курьера (сумма выполненных заказов)
app.get('/api/courier/balance', authenticate, async (req, res) => {
  if (req.user.role !== 'courier') return res.status(403).json({ error: 'Только курьеры' });
  try {
    const result = await pool.query(
      `SELECT COALESCE(SUM(price), 0) as total, COUNT(*) as delivered_count
       FROM orders
       WHERE courier_id = $1 AND status = 'delivered'`,
      [req.user.id]
    );
    res.json({
      balance: parseInt(result.rows[0].total),
      delivered: parseInt(result.rows[0].delivered_count)
    });
  } catch (err) {
    console.error('Ошибка получения баланса:', err);
    res.status(500).json({ error: 'Ошибка баланса' });
  }
});

// История сообщений заказа
app.get('/api/orders/:id/messages', authenticate, async (req, res) => {
  const orderId = req.params.id;
  try {
    const msgs = await pool.query(
      `SELECT m.*, u.name as sender_name
       FROM messages m
       JOIN users u ON u.id = m.sender_id
       WHERE m.order_id = $1
       ORDER BY m.created_at ASC`,
      [orderId]
    );
    res.json(msgs.rows);
  } catch (err) {
    console.error('Ошибка загрузки сообщений:', err);
    res.status(500).json({ error: 'Ошибка загрузки сообщений' });
  }
});

// ================== ПОДСКАЗКИ DADATA ==================
const fetch = require('node-fetch');
const DADATA_KEY = 'fdf2d91992e83bb16cfdbcbd557d2017387c7f20';

app.get('/api/suggest', authenticate, async (req, res) => {
  const { text } = req.query;
  if (!text || text.length < 2) return res.json({ results: [] });
  try {
    const url = 'https://suggestions.dadata.ru/suggestions/api/4_1/rs/suggest/address';
    const options = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': `Token ${DADATA_KEY}`
      },
      body: JSON.stringify({ query: text, count: 5, language: 'ru' })
    };
    const resp = await fetch(url, options);
    const data = await resp.json();
    const suggestions = (data.suggestions || []).map(s => ({
      title: { text: s.value },
      subtitle: { text: s.data?.region || '' }
    }));
    res.json({ results: suggestions });
  } catch (e) {
    console.error('Ошибка подсказок DaData:', e);
    res.status(500).json({ error: 'Ошибка подсказок' });
  }
});

// ================== РАСЧЁТ ЦЕНЫ (DaData + OSRM) ==================
app.post('/api/calculate-price', authenticate, async (req, res) => {
  const { pickup_address, delivery_address } = req.body;
  if (!pickup_address || !delivery_address) {
    return res.status(400).json({ error: 'Нужны оба адреса' });
  }
  try {
    const geocode = async (address) => {
      const url = 'https://suggestions.dadata.ru/suggestions/api/4_1/rs/suggest/address';
      const options = {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': `Token ${DADATA_KEY}`
        },
        body: JSON.stringify({ query: address, count: 1 })
      };
      const resp = await fetch(url, options);
      const data = await resp.json();
      const first = data.suggestions?.[0];
      if (first && first.data?.geo_lat && first.data?.geo_lon) {
        return { lat: parseFloat(first.data.geo_lat), lng: parseFloat(first.data.geo_lon) };
      }
      return null;
    };
    const [pickup, delivery] = await Promise.all([geocode(pickup_address), geocode(delivery_address)]);
    if (!pickup || !delivery) {
      return res.json({ price: 500, distance: '0.0', fixed: true });
    }
    const osrmUrl = `https://router.project-osrm.org/route/v1/driving/${pickup.lng},${pickup.lat};${delivery.lng},${delivery.lat}?overview=false`;
    const routeResp = await fetch(osrmUrl);
    const routeData = await routeResp.json();
    if (!routeData.routes || routeData.routes.length === 0) {
      return res.json({ price: 500, distance: '0.0', fixed: true });
    }
    const distanceKm = routeData.routes[0].distance / 1000;
    const price = Math.round(100 + distanceKm * 20);
    res.json({ price, distance: distanceKm.toFixed(1) });
  } catch (e) {
    console.error('Ошибка расчёта цены:', e);
    res.json({ price: 500, distance: '0.0', fixed: true });
  }
});

// ================== АДМИН‑ЭНДПОИНТЫ ==================
app.get('/api/admin/users', authenticate, async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Только для админа' });
  const { search } = req.query;
  try {
    let query = `SELECT id, name, phone, email, address, role FROM users WHERE role = 'client'`;
    const params = [];
    if (search) {
      query += ` AND (name ILIKE $1 OR phone ILIKE $1 OR email ILIKE $1 OR CAST(id AS TEXT) = $2)`;
      params.push(`%${search}%`, search);
    }
    query += ` ORDER BY id DESC`;
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err) {
    console.error('Ошибка получения пользователей:', err);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
});

app.get('/api/admin/couriers', authenticate, async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Только для админа' });
  const { search } = req.query;
  try {
    let query = `
      SELECT u.id, u.name, u.phone, u.email, u.address,
             c.full_name, c.transport, c.is_online, c.lat, c.lng
      FROM users u
      LEFT JOIN couriers c ON c.user_id = u.id
      WHERE u.role = 'courier'
    `;
    const params = [];
    if (search) {
      query += ` AND (u.name ILIKE $1 OR u.phone ILIKE $1 OR u.email ILIKE $1 OR CAST(u.id AS TEXT) = $2)`;
      params.push(`%${search}%`, search);
    }
    query += ` ORDER BY u.id DESC`;
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err) {
    console.error('Ошибка получения курьеров:', err);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
});

app.get('/api/admin/chats', authenticate, async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Только для админа' });
  try {
    const senders = await pool.query(
      `SELECT DISTINCT m.sender_id, u.name, u.role,
              (SELECT COUNT(*) FROM messages WHERE order_id = 0 AND sender_id = m.sender_id AND admin_read = false) as unread
       FROM messages m
       JOIN users u ON u.id = m.sender_id
       WHERE m.order_id = 0
       ORDER BY unread DESC, u.name`
    );
    res.json(senders.rows);
  } catch (err) {
    console.error('Ошибка получения чатов:', err);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
});

app.get('/api/admin/chat/:userId', authenticate, async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Только для админа' });
  const { userId } = req.params;
  try {
    const msgs = await pool.query(
      `SELECT m.*, u.name as sender_name
       FROM messages m
       JOIN users u ON u.id = m.sender_id
       WHERE m.order_id = 0 AND (m.sender_id = $1 OR m.sender_id = $2)
       ORDER BY m.created_at ASC`,
      [userId, req.user.id]
    );
    await pool.query(
      `UPDATE messages SET admin_read = true WHERE order_id = 0 AND sender_id = $1 AND admin_read = false`,
      [userId]
    );
    res.json(msgs.rows);
  } catch (err) {
    console.error('Ошибка получения чата:', err);
    res.status(500).json({ error: 'Ошибка сервера' });
  }
});

app.get('/api/admin/online-count', authenticate, async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Только для админа' });
  try {
    const count = await pool.query('SELECT COUNT(*) FROM couriers WHERE is_online = true');
    res.json({ online: parseInt(count.rows[0].count) });
  } catch (err) {
    res.status(500).json({ error: 'Ошибка сервера' });
  }
});

// ================== ЧЕРЕЗ SOCKET.IO ==================
io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  const token = socket.handshake.query.token;
  if (token) {
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      socket.userId = decoded.id;
      socket.userRole = decoded.role;
    } catch (err) {
      console.log('Socket auth error:', err.message);
    }
  }

  socket.on('join_room', (orderId) => {
    socket.join(`order_${orderId}`);
  });

  socket.on('send_message', async (data) => {
    const senderId = socket.userId;
    const { order_id, text } = data;
    if (!senderId || !order_id || !text) return;

    try {
      const user = await pool.query('SELECT name FROM users WHERE id = $1', [senderId]);
      const senderName = user.rows[0]?.name || 'Неизвестный';

      await pool.query(
        'INSERT INTO messages (order_id, sender_id, text) VALUES ($1,$2,$3)',
        [order_id, senderId, text]
      );

      io.to(`order_${order_id}`).emit('new_message', {
        sender_id: senderId,
        sender_name: senderName,
        text,
        time: new Date().toISOString()
      });
    } catch (err) {
      console.error('Ошибка сохранения сообщения:', err);
    }
  });

  socket.on('join_support', () => {
    socket.join('support');
  });

  socket.on('send_support_message', async (data) => {
    const senderId = socket.userId;
    const { text } = data;
    if (!senderId || !text) return;

    try {
      const user = await pool.query('SELECT name FROM users WHERE id = $1', [senderId]);
      const senderName = user.rows[0]?.name || 'Неизвестный';

      await pool.query(
        'INSERT INTO messages (order_id, sender_id, text) VALUES (0, $1, $2)',
        [senderId, text]
      );

      io.to('support').emit('new_support_message', {
        sender_id: senderId,
        sender_name: senderName,
        text,
        time: new Date().toISOString()
      });
    } catch (err) {
      console.error('Ошибка отправки сообщения в поддержку:', err);
    }
  });
});

server.listen(PORT, () => console.log(`Backend running on port ${PORT}`));